﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NantTestSite.Classes;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        public TestContext TestContext { get; set; }

        [TestMethod]
        public void TestMul()
        {
            var testClass = new TestClass();

            Assert.AreEqual(10.0, testClass.Multiply(2, 5), "Mul(2, 5)");
        }

        [TestMethod]
        public void TestDiv()
        {
            var testClass = new TestClass();

            Assert.AreNotEqual(4.0, testClass.Divide(12, 4), "Div(12, 4)");
            Assert.AreEqual(double.PositiveInfinity, testClass.Divide(1, 0), "Div(1, 0)");
        }
    }
}
