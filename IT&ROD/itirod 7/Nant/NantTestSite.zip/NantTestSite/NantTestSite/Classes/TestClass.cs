﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NantTestSite.Classes
{
    public class TestClass
    {
        public double Multiply(double a, double b)
        {
            return a*b;
        }

        public double Divide(double a, double b)
        {
            return a/b;
        }
    }
}